﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form15
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Panel5 = New Panel()
        Button4 = New Button()
        Button3 = New Button()
        Panel3 = New Panel()
        Button1 = New Button()
        TextBox10 = New TextBox()
        TextBox9 = New TextBox()
        TextBox8 = New TextBox()
        TextBox7 = New TextBox()
        TextBox6 = New TextBox()
        Label13 = New Label()
        Label12 = New Label()
        Label11 = New Label()
        Label10 = New Label()
        Label9 = New Label()
        Label8 = New Label()
        Label7 = New Label()
        Panel4 = New Panel()
        Button2 = New Button()
        TextBox12 = New TextBox()
        TextBox11 = New TextBox()
        Label15 = New Label()
        Label14 = New Label()
        Panel2 = New Panel()
        TextBox5 = New TextBox()
        TextBox4 = New TextBox()
        TextBox3 = New TextBox()
        TextBox2 = New TextBox()
        TextBox1 = New TextBox()
        Label6 = New Label()
        Label5 = New Label()
        Label4 = New Label()
        Label3 = New Label()
        Label2 = New Label()
        Label1 = New Label()
        Panel1 = New Panel()
        CheckBox3 = New CheckBox()
        CheckBox2 = New CheckBox()
        CheckBox1 = New CheckBox()
        PictureBox1 = New PictureBox()
        Panel5.SuspendLayout()
        Panel3.SuspendLayout()
        Panel4.SuspendLayout()
        Panel2.SuspendLayout()
        Panel1.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel5
        ' 
        Panel5.BackColor = SystemColors.ActiveCaptionText
        Panel5.Controls.Add(Button4)
        Panel5.Controls.Add(Button3)
        Panel5.Location = New Point(434, 544)
        Panel5.Name = "Panel5"
        Panel5.Size = New Size(316, 89)
        Panel5.TabIndex = 18
        ' 
        ' Button4
        ' 
        Button4.BackColor = SystemColors.ActiveCaptionText
        Button4.Cursor = Cursors.No
        Button4.ForeColor = Color.Snow
        Button4.Location = New Point(190, 13)
        Button4.Name = "Button4"
        Button4.Size = New Size(106, 34)
        Button4.TabIndex = 30
        Button4.Text = "close"
        Button4.UseVisualStyleBackColor = False
        ' 
        ' Button3
        ' 
        Button3.BackColor = SystemColors.ActiveCaptionText
        Button3.Cursor = Cursors.No
        Button3.ForeColor = Color.Snow
        Button3.Location = New Point(23, 13)
        Button3.Name = "Button3"
        Button3.Size = New Size(129, 34)
        Button3.TabIndex = 29
        Button3.Text = "add new"
        Button3.UseVisualStyleBackColor = False
        ' 
        ' Panel3
        ' 
        Panel3.BackColor = SystemColors.ActiveCaptionText
        Panel3.Controls.Add(Button1)
        Panel3.Controls.Add(TextBox10)
        Panel3.Controls.Add(TextBox9)
        Panel3.Controls.Add(TextBox8)
        Panel3.Controls.Add(TextBox7)
        Panel3.Controls.Add(TextBox6)
        Panel3.Controls.Add(Label13)
        Panel3.Controls.Add(Label12)
        Panel3.Controls.Add(Label11)
        Panel3.Controls.Add(Label10)
        Panel3.Controls.Add(Label9)
        Panel3.Controls.Add(Label8)
        Panel3.Controls.Add(Label7)
        Panel3.Location = New Point(453, 204)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(368, 334)
        Panel3.TabIndex = 19
        ' 
        ' Button1
        ' 
        Button1.BackColor = SystemColors.ActiveCaptionText
        Button1.ForeColor = SystemColors.ButtonHighlight
        Button1.Location = New Point(86, 228)
        Button1.Name = "Button1"
        Button1.Size = New Size(154, 34)
        Button1.TabIndex = 18
        Button1.Text = "compute hours"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' TextBox10
        ' 
        TextBox10.Location = New Point(195, 283)
        TextBox10.Name = "TextBox10"
        TextBox10.Size = New Size(150, 31)
        TextBox10.TabIndex = 25
        ' 
        ' TextBox9
        ' 
        TextBox9.Location = New Point(195, 179)
        TextBox9.Name = "TextBox9"
        TextBox9.Size = New Size(150, 31)
        TextBox9.TabIndex = 24
        ' 
        ' TextBox8
        ' 
        TextBox8.Location = New Point(195, 130)
        TextBox8.Name = "TextBox8"
        TextBox8.Size = New Size(150, 31)
        TextBox8.TabIndex = 23
        ' 
        ' TextBox7
        ' 
        TextBox7.Location = New Point(195, 69)
        TextBox7.Name = "TextBox7"
        TextBox7.Size = New Size(150, 31)
        TextBox7.TabIndex = 22
        ' 
        ' TextBox6
        ' 
        TextBox6.Location = New Point(195, 27)
        TextBox6.Name = "TextBox6"
        TextBox6.Size = New Size(150, 31)
        TextBox6.TabIndex = 18
        ' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.ForeColor = SystemColors.ButtonHighlight
        Label13.Location = New Point(29, 289)
        Label13.Name = "Label13"
        Label13.Size = New Size(129, 25)
        Label13.TabIndex = 21
        Label13.Text = "hours covered:"
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.ForeColor = SystemColors.ButtonHighlight
        Label12.Location = New Point(29, 182)
        Label12.Name = "Label12"
        Label12.Size = New Size(33, 25)
        Label12.TabIndex = 20
        Label12.Text = "to:"
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.ForeColor = SystemColors.ButtonHighlight
        Label11.Location = New Point(29, 31)
        Label11.Name = "Label11"
        Label11.Size = New Size(51, 25)
        Label11.TabIndex = 19
        Label11.Text = "date:"
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.ForeColor = SystemColors.ButtonHighlight
        Label10.Location = New Point(86, 105)
        Label10.Name = "Label10"
        Label10.Size = New Size(47, 25)
        Label10.TabIndex = 19
        Label10.Text = "time"
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.ForeColor = SystemColors.ButtonHighlight
        Label9.Location = New Point(16, 68)
        Label9.Name = "Label9"
        Label9.Size = New Size(137, 25)
        Label9.TabIndex = 19
        Label9.Text = "date and shoot:"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.ForeColor = SystemColors.ButtonHighlight
        Label8.Location = New Point(16, 136)
        Label8.Name = "Label8"
        Label8.Size = New Size(55, 25)
        Label8.TabIndex = 19
        Label8.Text = "from:"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.ForeColor = SystemColors.ButtonHighlight
        Label7.Location = New Point(16, -10)
        Label7.Name = "Label7"
        Label7.Size = New Size(139, 25)
        Label7.TabIndex = 18
        Label7.Text = "reservation info:"
        ' 
        ' Panel4
        ' 
        Panel4.BackColor = SystemColors.ActiveCaptionText
        Panel4.Controls.Add(Button2)
        Panel4.Controls.Add(TextBox12)
        Panel4.Controls.Add(TextBox11)
        Panel4.Controls.Add(Label15)
        Panel4.Controls.Add(Label14)
        Panel4.Location = New Point(37, 469)
        Panel4.Name = "Panel4"
        Panel4.Size = New Size(316, 164)
        Panel4.TabIndex = 17
        ' 
        ' Button2
        ' 
        Button2.BackColor = SystemColors.ActiveCaptionText
        Button2.Cursor = Cursors.No
        Button2.ForeColor = Color.Snow
        Button2.Location = New Point(67, 110)
        Button2.Name = "Button2"
        Button2.Size = New Size(154, 34)
        Button2.TabIndex = 26
        Button2.Text = "compute "
        Button2.UseVisualStyleBackColor = False
        ' 
        ' TextBox12
        ' 
        TextBox12.Location = New Point(134, 58)
        TextBox12.Name = "TextBox12"
        TextBox12.Size = New Size(150, 31)
        TextBox12.TabIndex = 28
        ' 
        ' TextBox11
        ' 
        TextBox11.Location = New Point(134, 12)
        TextBox11.Name = "TextBox11"
        TextBox11.Size = New Size(150, 31)
        TextBox11.TabIndex = 18
        ' 
        ' Label15
        ' 
        Label15.AutoSize = True
        Label15.ForeColor = SystemColors.ButtonHighlight
        Label15.Location = New Point(18, 61)
        Label15.Name = "Label15"
        Label15.Size = New Size(47, 25)
        Label15.TabIndex = 27
        Label15.Text = "time"
        ' 
        ' Label14
        ' 
        Label14.AutoSize = True
        Label14.ForeColor = SystemColors.ButtonHighlight
        Label14.Location = New Point(18, 18)
        Label14.Name = "Label14"
        Label14.Size = New Size(47, 25)
        Label14.TabIndex = 26
        Label14.Text = "time"
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = SystemColors.ActiveCaptionText
        Panel2.Controls.Add(TextBox5)
        Panel2.Controls.Add(TextBox4)
        Panel2.Controls.Add(TextBox3)
        Panel2.Controls.Add(TextBox2)
        Panel2.Controls.Add(TextBox1)
        Panel2.Controls.Add(Label6)
        Panel2.Controls.Add(Label5)
        Panel2.Controls.Add(Label4)
        Panel2.Controls.Add(Label3)
        Panel2.Controls.Add(Label2)
        Panel2.Controls.Add(Label1)
        Panel2.Location = New Point(0, 204)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(447, 245)
        Panel2.TabIndex = 16
        ' 
        ' TextBox5
        ' 
        TextBox5.Location = New Point(203, 182)
        TextBox5.Name = "TextBox5"
        TextBox5.Size = New Size(150, 31)
        TextBox5.TabIndex = 17
        ' 
        ' TextBox4
        ' 
        TextBox4.Location = New Point(203, 145)
        TextBox4.Name = "TextBox4"
        TextBox4.Size = New Size(150, 31)
        TextBox4.TabIndex = 16
        ' 
        ' TextBox3
        ' 
        TextBox3.Location = New Point(203, 105)
        TextBox3.Name = "TextBox3"
        TextBox3.Size = New Size(150, 31)
        TextBox3.TabIndex = 15
        ' 
        ' TextBox2
        ' 
        TextBox2.Location = New Point(203, 68)
        TextBox2.Name = "TextBox2"
        TextBox2.Size = New Size(150, 31)
        TextBox2.TabIndex = 14
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(203, 31)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(150, 31)
        TextBox1.TabIndex = 13
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.BorderStyle = BorderStyle.Fixed3D
        Label6.ForeColor = SystemColors.ButtonHighlight
        Label6.Location = New Point(16, 185)
        Label6.Name = "Label6"
        Label6.Size = New Size(140, 27)
        Label6.TabIndex = 12
        Label6.Text = "mobile number:"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.ForeColor = SystemColors.ButtonHighlight
        Label5.Location = New Point(16, 148)
        Label5.Name = "Label5"
        Label5.Size = New Size(128, 25)
        Label5.TabIndex = 11
        Label5.Text = "Email Address:"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.ForeColor = SystemColors.ButtonHighlight
        Label4.Location = New Point(16, 113)
        Label4.Name = "Label4"
        Label4.Size = New Size(63, 25)
        Label4.TabIndex = 10
        Label4.Text = "venue:"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.ForeColor = SystemColors.ButtonHighlight
        Label3.Location = New Point(16, 72)
        Label3.Name = "Label3"
        Label3.Size = New Size(60, 25)
        Label3.TabIndex = 9
        Label3.Text = "name:"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BorderStyle = BorderStyle.FixedSingle
        Label2.ForeColor = SystemColors.ButtonHighlight
        Label2.Location = New Point(16, 31)
        Label2.Name = "Label2"
        Label2.Size = New Size(131, 27)
        Label2.TabIndex = 8
        Label2.Text = "reservation no."
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.ForeColor = SystemColors.ButtonHighlight
        Label1.Location = New Point(16, -10)
        Label1.Name = "Label1"
        Label1.Size = New Size(190, 25)
        Label1.TabIndex = 0
        Label1.Text = "costurmer information"
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = SystemColors.ActiveCaptionText
        Panel1.Controls.Add(CheckBox3)
        Panel1.Controls.Add(CheckBox2)
        Panel1.Controls.Add(CheckBox1)
        Panel1.Location = New Point(0, 6)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(821, 169)
        Panel1.TabIndex = 14
        ' 
        ' CheckBox3
        ' 
        CheckBox3.AutoSize = True
        CheckBox3.ForeColor = SystemColors.ButtonHighlight
        CheckBox3.Location = New Point(16, 109)
        CheckBox3.Name = "CheckBox3"
        CheckBox3.Size = New Size(221, 29)
        CheckBox3.TabIndex = 4
        CheckBox3.Text = "in store/outside service"
        CheckBox3.UseVisualStyleBackColor = True
        ' 
        ' CheckBox2
        ' 
        CheckBox2.AutoSize = True
        CheckBox2.ForeColor = SystemColors.ButtonHighlight
        CheckBox2.Location = New Point(16, 57)
        CheckBox2.Name = "CheckBox2"
        CheckBox2.Size = New Size(155, 29)
        CheckBox2.TabIndex = 3
        CheckBox2.Text = "outside service"
        CheckBox2.UseVisualStyleBackColor = True
        ' 
        ' CheckBox1
        ' 
        CheckBox1.AutoSize = True
        CheckBox1.ForeColor = SystemColors.ButtonHighlight
        CheckBox1.Location = New Point(16, 3)
        CheckBox1.Name = "CheckBox1"
        CheckBox1.Size = New Size(155, 29)
        CheckBox1.TabIndex = 2
        CheckBox1.Text = "in store service"
        CheckBox1.UseVisualStyleBackColor = True
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackColor = SystemColors.ActiveCaptionText
        PictureBox1.Dock = DockStyle.Fill
        PictureBox1.Location = New Point(0, 0)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(837, 633)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 15
        PictureBox1.TabStop = False
        ' 
        ' Form15
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(837, 633)
        Controls.Add(Panel5)
        Controls.Add(Panel3)
        Controls.Add(Panel4)
        Controls.Add(Panel2)
        Controls.Add(Panel1)
        Controls.Add(PictureBox1)
        Name = "Form15"
        Text = "Form15"
        Panel5.ResumeLayout(False)
        Panel3.ResumeLayout(False)
        Panel3.PerformLayout()
        Panel4.ResumeLayout(False)
        Panel4.PerformLayout()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel5 As Panel
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Button1 As Button
    Friend WithEvents TextBox10 As TextBox
    Friend WithEvents TextBox9 As TextBox
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Button2 As Button
    Friend WithEvents TextBox12 As TextBox
    Friend WithEvents TextBox11 As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents CheckBox3 As CheckBox
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents PictureBox1 As PictureBox
End Class
