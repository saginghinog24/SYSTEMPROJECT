﻿Public Class Form13
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form14.Show()
        Me.Hide()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Form7.Show()
        Me.Hide()
    End Sub
End Class