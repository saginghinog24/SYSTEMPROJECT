﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Button2 = New Button()
        Button1 = New Button()
        TextBox6 = New TextBox()
        TextBox5 = New TextBox()
        TextBox4 = New TextBox()
        TextBox3 = New TextBox()
        TextBox2 = New TextBox()
        TextBox1 = New TextBox()
        Label7 = New Label()
        Label6 = New Label()
        Label5 = New Label()
        Label4 = New Label()
        Label3 = New Label()
        Label2 = New Label()
        Label1 = New Label()
        PictureBox3 = New PictureBox()
        pictureBox2 = New PictureBox()
        PictureBox1 = New PictureBox()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        CType(pictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(324, 498)
        Button2.Name = "Button2"
        Button2.Size = New Size(112, 34)
        Button2.TabIndex = 114
        Button2.Text = "cancel"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(159, 498)
        Button1.Name = "Button1"
        Button1.Size = New Size(112, 34)
        Button1.TabIndex = 113
        Button1.Text = "continue"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' TextBox6
        ' 
        TextBox6.Location = New Point(280, 409)
        TextBox6.Name = "TextBox6"
        TextBox6.Size = New Size(228, 31)
        TextBox6.TabIndex = 112
        ' 
        ' TextBox5
        ' 
        TextBox5.Location = New Point(280, 347)
        TextBox5.Name = "TextBox5"
        TextBox5.Size = New Size(228, 31)
        TextBox5.TabIndex = 111
        ' 
        ' TextBox4
        ' 
        TextBox4.Location = New Point(280, 281)
        TextBox4.Name = "TextBox4"
        TextBox4.Size = New Size(228, 31)
        TextBox4.TabIndex = 110
        ' 
        ' TextBox3
        ' 
        TextBox3.Location = New Point(280, 220)
        TextBox3.Name = "TextBox3"
        TextBox3.Size = New Size(228, 31)
        TextBox3.TabIndex = 109
        ' 
        ' TextBox2
        ' 
        TextBox2.Location = New Point(280, 163)
        TextBox2.Name = "TextBox2"
        TextBox2.Size = New Size(228, 31)
        TextBox2.TabIndex = 108
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(280, 94)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(228, 31)
        TextBox1.TabIndex = 107
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Location = New Point(40, 415)
        Label7.Name = "Label7"
        Label7.Size = New Size(158, 25)
        Label7.TabIndex = 106
        Label7.Text = "re enter password:"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Location = New Point(40, 226)
        Label6.Name = "Label6"
        Label6.Size = New Size(128, 25)
        Label6.TabIndex = 105
        Label6.Text = "Email Address:"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(40, 287)
        Label5.Name = "Label5"
        Label5.Size = New Size(93, 25)
        Label5.TabIndex = 104
        Label5.Text = "username:"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(40, 353)
        Label4.Name = "Label4"
        Label4.Size = New Size(93, 25)
        Label4.TabIndex = 103
        Label4.Text = "password:"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(40, 169)
        Label3.Name = "Label3"
        Label3.Size = New Size(106, 25)
        Label3.TabIndex = 102
        Label3.Text = "Contact No."
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(52, 100)
        Label2.Name = "Label2"
        Label2.Size = New Size(60, 25)
        Label2.TabIndex = 101
        Label2.Text = "name:"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = SystemColors.ControlDarkDark
        Label1.Font = New Font("Showcard Gothic", 14F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = SystemColors.Control
        Label1.Location = New Point(185, 21)
        Label1.Name = "Label1"
        Label1.Size = New Size(314, 35)
        Label1.TabIndex = 100
        Label1.Text = "REGISTRATION FORM"
        Label1.TextAlign = ContentAlignment.TopCenter
        ' 
        ' PictureBox3
        ' 
        PictureBox3.Dock = DockStyle.Fill
        PictureBox3.Image = My.Resources.Resources.efag
        PictureBox3.Location = New Point(0, 0)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(697, 550)
        PictureBox3.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox3.TabIndex = 116
        PictureBox3.TabStop = False
        ' 
        ' pictureBox2
        ' 
        pictureBox2.Dock = DockStyle.Fill
        pictureBox2.Location = New Point(0, 0)
        pictureBox2.Name = "pictureBox2"
        pictureBox2.Size = New Size(697, 550)
        pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage
        pictureBox2.TabIndex = 115
        pictureBox2.TabStop = False
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Dock = DockStyle.Fill
        PictureBox1.Location = New Point(0, 0)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(697, 550)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 99
        PictureBox1.TabStop = False
        ' 
        ' Form2
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(697, 550)
        Controls.Add(Button2)
        Controls.Add(Button1)
        Controls.Add(TextBox6)
        Controls.Add(TextBox5)
        Controls.Add(TextBox4)
        Controls.Add(TextBox3)
        Controls.Add(TextBox2)
        Controls.Add(TextBox1)
        Controls.Add(Label7)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(PictureBox3)
        Controls.Add(pictureBox2)
        Controls.Add(PictureBox1)
        Name = "Form2"
        Text = "Form2"
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        CType(pictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox3 As PictureBox
    Private WithEvents pictureBox2 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
End Class
